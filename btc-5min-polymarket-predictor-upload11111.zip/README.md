# BTC 5-Minute Polymarket Signal Monitor

Experimental signal-only dashboard for BTC 5-minute Up/Down markets.

## Deployment
The GitHub Actions workflow deploys the static site to GitHub Pages when files are pushed to `main`. If needed, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.

## Important limitations
- This prototype uses Binance BTCUSDT data as a proxy, not the Chainlink BTC/USD 60-second TWAP used by Polymarket market resolution rules.
- HIGHER/LOWER are rule-based signals, not calibrated probabilities or proven predictions.
- No historical backtest or accuracy claim has been established.
- It does not connect to a wallet or place trades.

Use as an experimental monitor only. Check the current market rules and price-to-beat on Polymarket before making decisions.
